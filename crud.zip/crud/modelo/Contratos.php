<?php

namespace App\Modelo;

use Illuminate\Database\Eloquent\Model;

class Contratos extends Model
{
    protected $table = 'contratos';
    protected $primaryKey = "id";
    protected $fillable = ['id','nacionalidad_titular','cedula_titular','nombre_titular_beneficiario','apellido_titular_beneficiario','estado_civil','sexo_titular_beneficiario','fecha_nacimiento_titular_beneficiario','parentesco','nombre_agente_recaudador','tipo_de_cuenta','numero_de_cuenta','tipo_de_vencimiento','codigo_empresa','codigo_sucursal','numero_de_telefono','correo_electronico','codigo_cia_seguro','codigo_plan_en_siser','codigo_productor_asesor','estado','estado_observacion'];
 
}


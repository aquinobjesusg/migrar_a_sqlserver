<?php
Route::apiResource('acontratos', App\Http\Controllers\apis\ContratosController::class);

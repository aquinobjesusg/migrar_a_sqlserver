<?php
Route::resource('contratos', App\Http\Controllers\tablas\ContratosController::class);
